LOAD DATA LOCAL INFILE 
 'C:/Anvesh Gorrepati - CPSC 50900 Database Systems Project/Data Sources/traveling_audit' 
 INTO TABLE traveling_audit FIELDS TERMINATED BY ';' (customer_id, service_id, place_id, transport_id, amount, start_date, end_date);