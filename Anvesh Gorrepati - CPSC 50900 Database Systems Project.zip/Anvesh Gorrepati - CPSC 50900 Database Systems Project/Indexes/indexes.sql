CREATE INDEX idx_Employee_Name
ON employee (full_name);


CREATE INDEX idx_Customer_Name
ON customer (full_name);


CREATE INDEX idx_Place_Name
ON place (place_name);