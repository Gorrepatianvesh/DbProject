CREATE DATABASE tourism_management;
USE tourism_management;
SOURCE C:/Anvesh Gorrepati - CPSC 50900 Database Systems Project/Data Definition Language Scripts/tourism_management.sql;