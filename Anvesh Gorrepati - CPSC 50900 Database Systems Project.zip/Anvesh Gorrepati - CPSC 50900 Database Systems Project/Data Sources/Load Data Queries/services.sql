LOAD DATA LOCAL INFILE 
 'C:/Anvesh Gorrepati - CPSC 50900 Database Systems Project/Data Sources/services' 
 INTO TABLE services FIELDS TERMINATED BY ';' (title, description, price);

