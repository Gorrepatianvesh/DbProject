import mysql.connector

# Create a database connection
connection = mysql.connector.connect(
    host="localhost", user="root", password="123", database="tourism_management"
)

db = connection.cursor()

# List representing the names of the tables to generate their reports
tables = [
    "customer",
    "designation",
    "employee",
    "place",
    "services",
    "transport",
    "transport_type",
    "traveling_audit",
]

# Iterate through the list of the tables and execute
# Select query to get its data and save it to the file
for table in tables:
    print("-----------------", table, "Table Data -----------------")
    # Create a file
    file = open(table, "w")
    # SQL Query to get data
    query = "SELECT * FROM " + table
    # Execute the query
    db.execute(query)
    result = db.fetchall()

    # Save the result in the file
    for row in result:
        file.write(str(row) + "\n")
        print(row)
