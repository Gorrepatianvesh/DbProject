LOAD DATA LOCAL INFILE 
 'C:/Anvesh Gorrepati - CPSC 50900 Database Systems Project/Data Sources/designation' 
 INTO TABLE designation FIELDS TERMINATED BY ';' (title);