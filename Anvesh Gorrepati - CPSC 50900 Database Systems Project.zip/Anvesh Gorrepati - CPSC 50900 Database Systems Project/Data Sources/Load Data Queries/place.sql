LOAD DATA LOCAL INFILE 
 'C:/Anvesh Gorrepati - CPSC 50900 Database Systems Project/Data Sources/place' 
 INTO TABLE place FIELDS TERMINATED BY ';' (place_name, city, country);
