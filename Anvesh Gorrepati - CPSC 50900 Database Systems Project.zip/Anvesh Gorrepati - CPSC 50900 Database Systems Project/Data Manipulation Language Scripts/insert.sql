INSERT INTO customer 
(full_name, address, email, contact) 
VALUES
("Martin", "221B, Baker Street",'martin@gmail.com', '+128387');


INSERT INTO designation 
(title) 
VALUES
("Accountant");