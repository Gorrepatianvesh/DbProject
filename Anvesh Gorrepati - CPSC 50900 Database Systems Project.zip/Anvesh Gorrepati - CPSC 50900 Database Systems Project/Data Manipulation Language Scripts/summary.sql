SELECT SUM(amount) AS "Total Income" FROM traveling_audit; 


SELECT COUNT(*) AS "Total Customers" FROM customer;