SELECT c.full_name AS "CUSTOMER", s.title AS "SERVICE", p.place_name AS "PLACE", t.name AS "TRANSPORT"
FROM customer c
INNER JOIN traveling_audit ta
ON c.id = ta.customer_id
INNER JOIN services s
ON s.id = ta.service_id
INNER JOIN place p
ON p.id = ta.place_id
INNER JOIN transport t
ON t.id = ta.transport_id;