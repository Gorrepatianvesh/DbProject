LOAD DATA LOCAL INFILE 
 'C:/Anvesh Gorrepati - CPSC 50900 Database Systems Project/Data Sources/customer' 
 INTO TABLE customer FIELDS TERMINATED BY ';' (full_name, address, email, contact);