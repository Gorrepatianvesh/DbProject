LOAD DATA LOCAL INFILE 
 'C:/Anvesh Gorrepati - CPSC 50900 Database Systems Project/Data Sources/transport_type' 
 INTO TABLE transport_type FIELDS TERMINATED BY ';' (title);