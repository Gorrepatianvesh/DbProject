LOAD DATA LOCAL INFILE 
 'C:/Anvesh Gorrepati - CPSC 50900 Database Systems Project/Data Sources/employee' 
 INTO TABLE employee FIELDS TERMINATED BY ';' (full_name, contact, designation_id);