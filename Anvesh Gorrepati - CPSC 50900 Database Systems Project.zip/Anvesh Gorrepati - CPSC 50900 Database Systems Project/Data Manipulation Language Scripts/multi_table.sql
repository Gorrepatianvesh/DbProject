SELECT full_name FROM employee
UNION
SELECT title FROM designation;