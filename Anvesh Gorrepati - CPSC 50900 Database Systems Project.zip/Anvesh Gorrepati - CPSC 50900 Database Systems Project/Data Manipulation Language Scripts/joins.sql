SELECT e.full_name, e.contact, d.title AS "Designation"
FROM employee e, designation d
WHERE e.designation_id = d.id;


SELECT t.name, t.capacity, tt.title AS "Transport Type"
FROM transport t, transport_type tt
WHERE t.transport_type_id = tt.id;

