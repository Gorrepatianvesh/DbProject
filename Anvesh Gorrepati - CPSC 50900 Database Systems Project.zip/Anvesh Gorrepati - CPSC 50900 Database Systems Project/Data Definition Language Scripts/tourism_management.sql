--
-- Table structure for table customer
--

CREATE TABLE customer (
  id int(11) NOT NULL,
  full_name varchar(255) NOT NULL,
  address varchar(255) NOT NULL,
  email varchar(255) NOT NULL,
  contact varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table designation
--

CREATE TABLE designation (
  id int(11) NOT NULL,
  title varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table employee
--

CREATE TABLE employee (
  id int(11) NOT NULL,
  full_name varchar(255) NOT NULL,
  contact varchar(255) NOT NULL,
  designation_id int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table place
--

CREATE TABLE place (
  id int(11) NOT NULL,
  place_name varchar(255) NOT NULL,
  city varchar(255) NOT NULL,
  country varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table services
--

CREATE TABLE services (
  id int(11) NOT NULL,
  title varchar(255) NOT NULL,
  description varchar(255) NOT NULL,
  price double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table transport
--

CREATE TABLE transport (
  id int(11) NOT NULL,
  name varchar(255) NOT NULL,
  capacity varchar(255) NOT NULL,
  transport_type_id int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table transport_type
--

CREATE TABLE transport_type (
  id int(11) NOT NULL,
  title varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table traveling_audit
--

CREATE TABLE traveling_audit (
  id int(11) NOT NULL,
  customer_id int(11) NOT NULL,
  service_id int(11) NOT NULL,
  place_id int(11) NOT NULL,
  transport_id int(11) NOT NULL,
  amount double NOT NULL,
  start_date date NOT NULL,
  end_date date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for table customer
--
ALTER TABLE customer
  ADD PRIMARY KEY (id);

--
-- Indexes for table designation
--
ALTER TABLE designation
  ADD PRIMARY KEY (id);

--
-- Indexes for table employee
--
ALTER TABLE employee
  ADD PRIMARY KEY (id),
  ADD KEY FK_DESIGNATION_ID (designation_id);

--
-- Indexes for table place
--
ALTER TABLE place
  ADD PRIMARY KEY (id);

--
-- Indexes for table services
--
ALTER TABLE services
  ADD PRIMARY KEY (id);

--
-- Indexes for table transport
--
ALTER TABLE transport
  ADD PRIMARY KEY (id),
  ADD KEY FK_TRANSPORT_TYPE (transport_type_id);

--
-- Indexes for table transport_type
--
ALTER TABLE transport_type
  ADD PRIMARY KEY (id);

--
-- Indexes for table traveling_audit
--
ALTER TABLE traveling_audit
  ADD PRIMARY KEY (id),
  ADD KEY FK_CUSTOMER (customer_id),
  ADD KEY FK_SERVICE (service_id),
  ADD KEY FK_PLACE (place_id),
  ADD KEY FK_TRANSPORT (transport_id);

--
-- AUTO_INCREMENT for table customer
--
ALTER TABLE customer
  MODIFY id int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table designation
--
ALTER TABLE designation
  MODIFY id int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table employee
--
ALTER TABLE employee
  MODIFY id int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table place
--
ALTER TABLE place
  MODIFY id int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table services
--
ALTER TABLE services
  MODIFY id int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table transport
--
ALTER TABLE transport
  MODIFY id int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table transport_type
--
ALTER TABLE transport_type
  MODIFY id int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table traveling_audit
--
ALTER TABLE traveling_audit
  MODIFY id int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for table employee
--
ALTER TABLE employee
  ADD CONSTRAINT FK_DESIGNATION_ID FOREIGN KEY (designation_id) REFERENCES designation (id) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table transport
--
ALTER TABLE transport
  ADD CONSTRAINT FK_TRANSPORT_TYPE FOREIGN KEY (transport_type_id) REFERENCES transport_type (id) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table traveling_audit
--
ALTER TABLE traveling_audit
  ADD CONSTRAINT FK_CUSTOMER FOREIGN KEY (customer_id) REFERENCES customer (id) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT FK_PLACE FOREIGN KEY (place_id) REFERENCES place (id) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT FK_SERVICE FOREIGN KEY (service_id) REFERENCES services (id) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT FK_TRANSPORT FOREIGN KEY (transport_id) REFERENCES transport (id) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;
