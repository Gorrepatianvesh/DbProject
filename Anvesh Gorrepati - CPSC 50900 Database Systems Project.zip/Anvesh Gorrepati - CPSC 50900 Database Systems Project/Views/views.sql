CREATE VIEW Employee_Designation AS
SELECT e.full_name, e.contact, d.title AS "Designation"
FROM employee e, designation d
WHERE e.designation_id = d.id;


CREATE VIEW Traveling_Audit_View AS
SELECT c.full_name AS "CUSTOMER", s.title AS "SERVICE", p.place_name AS "PLACE", t.name AS "TRANSPORT"
FROM customer c
INNER JOIN traveling_audit ta
ON c.id = ta.customer_id
INNER JOIN services s
ON s.id = ta.service_id
INNER JOIN place p
ON p.id = ta.place_id
INNER JOIN transport t
ON t.id = ta.transport_id;