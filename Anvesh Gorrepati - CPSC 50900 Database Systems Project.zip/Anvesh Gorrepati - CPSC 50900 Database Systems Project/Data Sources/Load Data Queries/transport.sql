LOAD DATA LOCAL INFILE 
 'C:/Anvesh Gorrepati - CPSC 50900 Database Systems Project/Data Sources/transport' 
 INTO TABLE transport FIELDS TERMINATED BY ';' (name, capacity, transport_type_id);