UPDATE customer SET full_name = 'Glen' WHERE id = 2;

UPDATE designation SET title = "Guide" WHERE ID = 2;